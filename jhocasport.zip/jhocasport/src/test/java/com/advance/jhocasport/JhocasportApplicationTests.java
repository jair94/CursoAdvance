package com.advance.jhocasport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JhocasportApplicationTests {

	@Test
	void contextLoads() {
	}

}
