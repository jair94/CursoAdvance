package com.advance.jhocasport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JhocasportApplication {

	public static void main(String[] args) {
		SpringApplication.run(JhocasportApplication.class, args);
	}

}
