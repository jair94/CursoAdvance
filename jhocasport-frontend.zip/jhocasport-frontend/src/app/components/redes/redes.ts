import { Component } from '@angular/core';

@Component({
  selector: 'app-redes',
  imports: [],
  templateUrl: './redes.html',
  styleUrl: './redes.css'
})
export class Redes {

}
