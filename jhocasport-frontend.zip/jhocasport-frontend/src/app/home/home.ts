import { Component } from '@angular/core';
import { Menu } from '../components/menu/menu';
import { Carrusel } from '../components/carrusel/carrusel';
import { Tarjetas } from '../components/tarjetas/tarjetas';
import { Redes } from '../components/redes/redes';
import { Preguntas } from '../components/preguntas/preguntas';

@Component({
  selector: 'app-home',
  imports: [Menu, Carrusel, Tarjetas, Preguntas, Redes],
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class Home {

}
